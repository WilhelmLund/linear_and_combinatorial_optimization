function string=inttostring(istring,alf)
% inttostring konverterar mellan heltalsstrn~�ngar och
% bokstavstr�ngar.

string=alf(istring);
