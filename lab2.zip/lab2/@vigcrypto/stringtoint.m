function istring=stringtoint(string,ialf);

istring=ialf(double(string));
















