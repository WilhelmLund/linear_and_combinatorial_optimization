function domain = getdomain(problem);
% function domain = getdomain(problem);
% VIGCRYPTO/GETDOMAIN - Generates a representation of
% the domain of the problem.
%

domain=-1*ones(1,problem.keylength);
