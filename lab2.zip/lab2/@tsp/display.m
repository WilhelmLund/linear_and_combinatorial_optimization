function display(s);
% function display(s);
% TSP/DISPLAY Command window display of an msegment;
%

disp(' ');
disp([inputname(1),' = '])
disp(' ');
disp(['Travelling salesman problem with ' num2str(s.n) ' cities.'])
disp(' ');
