% Generates data for the transportation problem 
% in Example 1 of chapter 5.1 in 
% Kolman, Beck: Elementary Linear Programming with applications.
s=[120 140 100]';
d=[100 60 80 120]';
c=[5 7 9 6;6 7 10 5;7 6 8 1];
