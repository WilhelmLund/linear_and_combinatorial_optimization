% Generates data for the transportation problem 
% in Example 3 of chapter 5.1 in 
% Kolman, Beck: Elementary Linear Programming with applications.
s=[100 160 100]';
d=[50 60 80 100 70]';
c=[9 3 6 7 3;7 5 2 10 6;5 4 9 8 10];
